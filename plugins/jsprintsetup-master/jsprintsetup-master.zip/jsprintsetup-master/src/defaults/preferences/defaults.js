// Default values to preferences
pref("extensions.jsprintsetup.security_mode", "prompt");
pref("extensions.jsprintsetup.localfiles_enabled", true);
pref("extensions.jsprintsetup.allow_blocked_request", true);